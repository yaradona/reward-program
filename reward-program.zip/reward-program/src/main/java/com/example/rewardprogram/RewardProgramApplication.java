package com.example.rewardprogram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RewardProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(RewardProgramApplication.class, args);
	}

}
