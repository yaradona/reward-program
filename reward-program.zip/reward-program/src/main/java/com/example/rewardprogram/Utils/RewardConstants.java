package com.example.rewardprogram.Utils;

public class RewardConstants {

	public static final int REWARDS_THRESHOLD_NUMBER_HUNDRED = 100;
	public static final int REWARDS_THRESHOLD_NUMBER_FIFTY = 50;
}
