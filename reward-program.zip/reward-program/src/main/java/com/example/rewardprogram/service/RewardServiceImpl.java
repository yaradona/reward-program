package com.example.rewardprogram.service;

import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.aop.AopInvocationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.rewardprogram.Utils.RewardConstants;
import com.example.rewardprogram.advice.error.CustomerNotFoundException;
import com.example.rewardprogram.dto.RewardsResponse;
import com.example.rewardprogram.model.CustomerTranscation;
import com.example.rewardprogram.repository.RewardRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RewardServiceImpl implements RewardService {

	@Autowired
	private RewardRepository rewardRepository;

	public RewardsResponse getRewardPoints(String customerId) throws CustomerNotFoundException {

		// Reward points for over 50$
		int rewardPointsLevelOne = 0;

		// Reward points for over 100$
		int rewardPointsLevelTwo = 0;

		int totalRewardPoints = 0;
		List<CustomerTranscation> customerTranscationList;
		try {
			customerTranscationList = rewardRepository.findByCustomerId(customerId);

			ListIterator<CustomerTranscation> customerTranscationIter = customerTranscationList.listIterator();

			while (customerTranscationIter.hasNext()) {

				CustomerTranscation customerTxObj = customerTranscationIter.next();
				double transaction_amount = customerTxObj.getTransacationAmount();

				if (transaction_amount > RewardConstants.REWARDS_THRESHOLD_NUMBER_HUNDRED) {
					rewardPointsLevelTwo = (int) ((transaction_amount
							- RewardConstants.REWARDS_THRESHOLD_NUMBER_HUNDRED) * 2);
					rewardPointsLevelOne = (int) ((transaction_amount - RewardConstants.REWARDS_THRESHOLD_NUMBER_FIFTY)
							- (transaction_amount - RewardConstants.REWARDS_THRESHOLD_NUMBER_HUNDRED));
				} else {
					rewardPointsLevelOne = (int) (transaction_amount - RewardConstants.REWARDS_THRESHOLD_NUMBER_FIFTY);
				}

				totalRewardPoints = rewardPointsLevelTwo + rewardPointsLevelOne;
				customerTxObj.setRewardPoints(totalRewardPoints);
				rewardRepository.save(customerTxObj);
			}

			List<Object[]> customerRewardsReport = rewardRepository.rewardsPointsPerMonth(customerId);
			Map<String, Long> rewardsMap = customerRewardsReport.stream()
					.collect(Collectors.toMap(a -> (String) a[0], a -> (Long) a[1]));

			Integer totalRewardsPoints = rewardRepository.totalRewardsPoints(customerId);
			return new RewardsResponse(customerId, rewardsMap, totalRewardsPoints);

		} catch (AopInvocationException e) {
			log.error(" AopInvocationException occured in getRewardPoints ", e);
			if (null == e.getRootCause())
				throw new CustomerNotFoundException("Customer details are not found for customerId - " + customerId);
		}
		return null;

	}

}
